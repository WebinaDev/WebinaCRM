import { TableListSkeleton } from "@/components/TableListSkeleton"
import { useCallback, useEffect, useState } from "react"
import { Link } from "react-router-dom"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SELECT_ALL_VALUE } from "@/lib/constants"
import { restGetJson } from "@/api/client"
import { getLogs, getSystemLogs, type LogEntry, type SystemLogEntry } from "@/api/logs"
import { useLocale } from "@/hooks/use-locale"
import { CrmPageLayout } from "@/features/shared/layout/CrmPageLayout"
import { PmFilterBar } from "@/features/shared/pm/PmFilterBar"
import { PmPagination } from "@/features/shared/pm/PmPagination"
import { PmEmptyState } from "@/features/shared/pm/PmEmptyState"
import { usePmPagination } from "@/features/shared/pm/usePmPagination"
import { useDebouncedValue } from "@/features/shared/pm/useDebouncedValue"
import { History, Settings, CheckCircle } from "lucide-react"
import { cn } from "@/lib/utils"

type BaleLog = {
  id: string
  level: string
  log_type: string
  context: string
  created_at: string
}

const LOG_LEVELS = ["", "error", "warning", "info", "debug"] as const

export function LogsPage() {
  const { t, isRtl, formatDateTime } = useLocale()
  const [activeTab, setActiveTab] = useState("events")
  const [events, setEvents] = useState<LogEntry[]>([])
  const [systemLogs, setSystemLogs] = useState<SystemLogEntry[]>([])
  const [baleLogs, setBaleLogs] = useState<BaleLog[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const [search, setSearch] = useState("")
  const [actionFilter, setActionFilter] = useState("")
  const [levelFilter, setLevelFilter] = useState("")
  const debouncedSearch = useDebouncedValue(search)

  const {
    currentPage: eventsPage,
    setCurrentPage: setEventsPage,
    totalPages: eventsTotalPages,
    setTotalPages: setEventsTotalPages,
    resetPage: resetEventsPage,
  } = usePmPagination()
  const {
    currentPage: systemPage,
    setCurrentPage: setSystemPage,
    totalPages: systemTotalPages,
    setTotalPages: setSystemTotalPages,
    resetPage: resetSystemPage,
  } = usePmPagination()

  const loadEvents = useCallback(
    async (page = 1) => {
      setLoading(true)
      setError(null)
      try {
        const res = await getLogs({
          log_tab: "events",
          paged: page,
          s: debouncedSearch.trim() || undefined,
          action_filter: actionFilter || undefined,
        })
        if (res.success && res.data) {
          const d = res.data as { logs: LogEntry[]; total_pages: number }
          setEvents(d.logs ?? [])
          setEventsTotalPages(Math.max(1, d.total_pages ?? 1))
          setEventsPage(page)
        } else {
          setError(res.message ?? t("pages.logs.خطا_در_بارگذاری_لاگها"))
        }
      } catch {
        setError(t("pages.logs.خطا_در_بارگذاری_لاگها"))
      } finally {
        setLoading(false)
      }
    },
    [debouncedSearch, actionFilter, setEventsTotalPages, setEventsPage, t],
  )

  const loadSystem = useCallback(
    async (page = 1) => {
      setLoading(true)
      setError(null)
      try {
        const res = await getSystemLogs({
          paged: page,
          s: debouncedSearch.trim() || undefined,
          level: levelFilter || undefined,
        })
        if (res.success && res.data) {
          const d = res.data
          setSystemLogs(d.logs ?? [])
          setSystemTotalPages(Math.max(1, d.total_pages ?? 1))
          setSystemPage(page)
        } else {
          setError(res.message ?? t("pages.logs.خطا_در_بارگذاری_لاگها"))
        }
      } catch {
        setError(t("pages.logs.خطا_در_بارگذاری_لاگها"))
      } finally {
        setLoading(false)
      }
    },
    [debouncedSearch, levelFilter, setSystemTotalPages, setSystemPage, t],
  )

  const loadBaleLogs = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await restGetJson<{ logs: BaleLog[] }>("webinocrm/v1/bale/logs?limit=120")
      if (res.ok && res.data?.logs) {
        setBaleLogs(res.data.logs)
      } else {
        setError(res.message ?? t("pages.logs.خطا_در_بارگذاری_لاگهای_بله"))
      }
    } catch {
      setError(t("pages.logs.خطا_در_بارگذاری_لاگهای_بله"))
    } finally {
      setLoading(false)
    }
  }, [t])

  useEffect(() => {
    if (activeTab === "events") resetEventsPage()
    else if (activeTab === "system") resetSystemPage()
  }, [activeTab, debouncedSearch, actionFilter, levelFilter, resetEventsPage, resetSystemPage])

  useEffect(() => {
    if (activeTab === "events") void loadEvents(eventsPage)
    else if (activeTab === "system") void loadSystem(systemPage)
    else void loadBaleLogs()
  }, [activeTab, eventsPage, systemPage, loadEvents, loadSystem, loadBaleLogs])

  const applyFilters = () => {
    if (activeTab === "events") {
      resetEventsPage()
      void loadEvents(1)
    } else if (activeTab === "system") {
      resetSystemPage()
      void loadSystem(1)
    }
  }

  const renderBaleTable = () => (
    <>
      <div
        className={cn(
          "mb-4 flex flex-wrap items-center justify-between gap-2 text-start",
          isRtl && "flex-row-reverse",
        )}
      >
        <h3 className="font-medium">{t("pages.logs.لاگهای_ربات_بله_CRM")}</h3>
        <Button variant="outline" size="sm" asChild>
          <Link to="/bale-business?tab=logs">{t("pages.logs.رفتن_به_ربات_کسبوکار")}</Link>
        </Button>
      </div>
      <p className="text-sm text-muted-foreground mb-4">{t("pages.logs.مشاهده_در_ربات_کسبوکار")}</p>
      {loading ? (

        <TableListSkeleton rows={8} columns={5} />

      ) : baleLogs.length === 0 ? (
        <PmEmptyState message={t("pages.logs.لاگی_برای_ربات_بله_ثبت_نشده_است")} />
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>{t("pages.balebusiness.زمان")}</TableHead>
              <TableHead>{t("pages.accounting.chartOfAccounts.سطح")}</TableHead>
              <TableHead>{t("pages.accounting.cashAccounts.نوع")}</TableHead>
              <TableHead>{t("pages.logs.جزئیات")}</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {baleLogs.map((log) => (
              <TableRow key={log.id}>
                <TableCell>{formatDateTime(log.created_at)}</TableCell>
                <TableCell>{log.level}</TableCell>
                <TableCell>{log.log_type}</TableCell>
                <TableCell className="max-w-md truncate">{log.context}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </>
  )

  const renderEventsTable = () => (
    <>
      <h3 className="flex items-center gap-2 mb-4 font-medium">
        <History className="h-5 w-5" />
        {t("pages.logs.لاگ_رویدادها")}
      </h3>
      {loading ? (

        <TableListSkeleton rows={8} columns={5} />

      ) : events.length === 0 ? (
        <PmEmptyState message={t("pages.logs.هیچ_لاگی_برای_نمایش_وجود_ندارد")} />
      ) : (
        <>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t("pages.logs.رویداد")}</TableHead>
                <TableHead>{t("pages.logs.جزئیات")}</TableHead>
                <TableHead>{t("pages.customers.کاربر")}</TableHead>
                <TableHead>{t("common.date")}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {events.map((log) => (
                <TableRow key={log.id}>
                  <TableCell className="font-medium">{log.title}</TableCell>
                  <TableCell className="max-w-md truncate" title={log.content}>
                    {log.content}
                  </TableCell>
                  <TableCell>{log.author}</TableCell>
                  <TableCell>{log.date ? formatDateTime(log.date) : "—"}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <PmPagination
            page={eventsPage}
            totalPages={eventsTotalPages}
            onPageChange={(p) => void loadEvents(p)}
            prevLabel={t("pages.logs.prev")}
            nextLabel={t("pages.logs.next")}
            isRtl={isRtl}
          />
        </>
      )}
    </>
  )

  const renderSystemTable = () => (
    <>
      <h3 className="flex items-center gap-2 mb-2 font-medium">
        <Settings className="h-5 w-5" />
        {t("pages.logs.لاگ_سیستم")}
      </h3>
      <p className="text-sm text-muted-foreground mb-4">{t("pages.logs.system_tab_hint")}</p>
      {loading ? (

        <TableListSkeleton rows={8} columns={5} />

      ) : systemLogs.length === 0 ? (
        <PmEmptyState
          icon={CheckCircle}
          message={t("pages.logs.هیچ_خطای_سیستمی_برای_نمایش_وجود_ندارد")}
          className="text-green-600"
        />
      ) : (
        <>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t("pages.logs.عنوان_خطا")}</TableHead>
                <TableHead>{t("pages.accounting.chartOfAccounts.سطح")}</TableHead>
                <TableHead>{t("pages.logs.جزئیات")}</TableHead>
                <TableHead>{t("common.date")}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {systemLogs.map((log) => (
                <TableRow key={log.id}>
                  <TableCell className="font-medium">{log.message}</TableCell>
                  <TableCell>{log.severity ?? log.level}</TableCell>
                  <TableCell className="max-w-md" title={log.context ?? ""}>
                    <span className="line-clamp-2">{log.context || log.log_type}</span>
                  </TableCell>
                  <TableCell>{formatDateTime(log.created_at)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <PmPagination
            page={systemPage}
            totalPages={systemTotalPages}
            onPageChange={(p) => void loadSystem(p)}
            prevLabel={t("pages.logs.prev")}
            nextLabel={t("pages.logs.next")}
            isRtl={isRtl}
          />
        </>
      )}
    </>
  )

  return (
    <CrmPageLayout
      title={t("pages.logs.لاگهای_سیستم")}
      error={error}
      onDismissError={() => setError(null)}
    >
      {(activeTab === "events" || activeTab === "system") && (
        <PmFilterBar applyLabel={t("common.search")} onApply={applyFilters} isRtl={isRtl}>
          <Input
            placeholder={t("common.search")}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="max-w-xs"
          />
          {activeTab === "events" && (
            <Input
              placeholder={t("pages.logs.رویداد")}
              value={actionFilter}
              onChange={(e) => setActionFilter(e.target.value)}
              className="max-w-[160px]"
            />
          )}
          {activeTab === "system" && (
            <Select
              value={levelFilter || SELECT_ALL_VALUE}
              onValueChange={(v) => setLevelFilter(v === SELECT_ALL_VALUE ? "" : v)}
            >
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder={t("pages.accounting.chartOfAccounts.سطح")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={SELECT_ALL_VALUE}>{t("pages.reports.columns.all")}</SelectItem>
                {LOG_LEVELS.filter(Boolean).map((lvl) => (
                  <SelectItem key={lvl} value={lvl}>
                    {lvl}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </PmFilterBar>
      )}

      <Card className="text-start" dir={isRtl ? "rtl" : "ltr"}>
        <CardContent className="pt-6 text-start">
          <Tabs value={activeTab} onValueChange={setActiveTab} dir={isRtl ? "rtl" : "ltr"} className="text-start">
            <TabsList className="text-start">
              <TabsTrigger value="events">{t("pages.logs.لاگ_رویدادها")}</TabsTrigger>
              <TabsTrigger value="system">{t("pages.logs.لاگ_سیستم")}</TabsTrigger>
              <TabsTrigger value="bale">{t("pages.logs.لاگ_ربات_بله")}</TabsTrigger>
            </TabsList>
            <TabsContent value="events" className="mt-4">
              {renderEventsTable()}
            </TabsContent>
            <TabsContent value="system" className="mt-4">
              {renderSystemTable()}
            </TabsContent>
            <TabsContent value="bale" className="mt-4">
              {renderBaleTable()}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </CrmPageLayout>
  )
}
