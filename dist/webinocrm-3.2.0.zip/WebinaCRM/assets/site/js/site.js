(function () {
	'use strict';

	document.documentElement.setAttribute('dir', 'rtl');

	var cfg = window.webinaSite || {};

	/* Mega menu desktop + mobile */
	function initMegaMenu() {
		var header = document.getElementById('webina-mega-header');
		if (!header) return;

		var triggers = header.querySelectorAll('.webina-mega-trigger');
		var panels = header.querySelectorAll('.webina-mega-panel');
		var toggle = header.querySelector('.webina-mega-header__toggle');
		var nav = header.querySelector('.webina-mega-header__nav');

		function closeAll() {
			triggers.forEach(function (t) {
				t.setAttribute('aria-expanded', 'false');
			});
			panels.forEach(function (p) {
				p.hidden = true;
			});
		}

		triggers.forEach(function (trigger) {
			trigger.addEventListener('click', function (e) {
				e.preventDefault();
				e.stopPropagation();
				var id = trigger.getAttribute('data-mega');
				var panel = header.querySelector('[data-mega-panel="' + id + '"]');
				if (!panel) return;
				var open = panel.hidden;
				closeAll();
				if (open) {
					panel.hidden = false;
					trigger.setAttribute('aria-expanded', 'true');
				}
			});
		});

		document.addEventListener('click', function (e) {
			if (!header.contains(e.target)) closeAll();
		});

		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape') closeAll();
		});

		if (toggle && nav) {
			toggle.addEventListener('click', function () {
				var open = nav.classList.toggle('is-open');
				toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
			});
		}
	}

	/* Stats counter on scroll */
	function initStatsCounter() {
		var items = document.querySelectorAll('.webina-stats__item strong[data-count]');
		if (!items.length) return;

		var ran = false;
		function animate() {
			if (ran) return;
			var visible = false;
			items.forEach(function (el) {
				var rect = el.getBoundingClientRect();
				if (rect.top < window.innerHeight * 0.9) visible = true;
			});
			if (!visible) return;
			ran = true;
			items.forEach(function (el) {
				var target = el.getAttribute('data-count') || '';
				if (!/^\d+$/.test(target)) return;
				var end = parseInt(target, 10);
				var start = 0;
				var step = Math.max(1, Math.floor(end / 40));
				var timer = setInterval(function () {
					start += step;
					if (start >= end) {
						var suffix = el.getAttribute('data-suffix') || '';
						el.textContent = suffix ? end + suffix : String(end);
						clearInterval(timer);
					} else {
						el.textContent = String(start);
					}
				}, 30);
			});
		}

		window.addEventListener('scroll', animate, { passive: true });
		animate();
	}

	/* Lead form AJAX */
	function initLeadForms() {
		document.querySelectorAll('.webina-lead-form').forEach(function (form) {
			form.addEventListener('submit', function (e) {
				e.preventDefault();
				if (!cfg.ajaxUrl || !cfg.leadNonce) return;

				var btn = form.querySelector('button[type="submit"]');
				var status = form.querySelector('.webina-lead-form__status');
				if (btn) btn.disabled = true;

				var body = new FormData();
				body.append('action', cfg.leadAction || 'webinocrm_site_lead');
				body.append('nonce', cfg.leadNonce);
				body.append('name', (form.querySelector('[name="webina_name"]') || {}).value || '');
				body.append('phone', (form.querySelector('[name="webina_phone"]') || {}).value || '');
				body.append('message', (form.querySelector('[name="webina_message"]') || {}).value || '');
				body.append('page_url', window.location.href);

				fetch(cfg.ajaxUrl, { method: 'POST', body: body, credentials: 'same-origin' })
					.then(function (r) { return r.json(); })
					.then(function (data) {
						if (status) {
							status.textContent = (data.data && data.data.message) || (data.message) || 'ارسال شد';
							status.classList.toggle('is-error', !data.success);
						}
						if (data.success) form.reset();
					})
					.catch(function () {
						if (status) {
							status.textContent = 'خطا در ارسال. دوباره تلاش کنید.';
							status.classList.add('is-error');
						}
					})
					.finally(function () {
						if (btn) btn.disabled = false;
					});
			});
		});
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', function () {
			initMegaMenu();
			initStatsCounter();
			initLeadForms();
		});
	} else {
		initMegaMenu();
		initStatsCounter();
		initLeadForms();
	}
})();
