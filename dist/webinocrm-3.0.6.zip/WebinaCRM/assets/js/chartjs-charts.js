(function () {
    "use strict";

    /* line chart  */
    Chart.defaults.borderColor = "rgba(142, 156, 173,0.1)", Chart.defaults.color = "#8c9097";
    const labels = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور'];



    const data = {
        labels: labels,
        datasets: [{
            label: 'تست',
            backgroundColor: 'rgb(84, 109, 254)',
            borderColor: 'rgb(84, 109, 254)',
            data: [0, 10, 5, 2, 20, 30, 45],
        }]
    };
    const config = {
        type: 'line',
        data: data,
        options: {}
    };
    const myChart = new Chart(
        document.getElementById('chartjs-line'),
        config
    );

    /* bar chart */
    const labels1 = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر'];
    const data1 = {
        labels: labels1,
        datasets: [{
            label: 'تست',
            data: [65, 59, 80, 81, 56, 55, 40],
            backgroundColor: [
                'rgba(84, 109, 254, 0.2)',
                'rgba(175 ,109, 237, 0.2)',
                'rgba(244, 167, 66, 0.2)',
                'rgba(12, 163, 231, 0.2)',
                'rgba(254, 84, 84, 0.2)',
                'rgba(40 ,215 ,133, 0.2)',
                'rgba(10, 10, 10, 0.2)'
            ],
            borderColor: [ 
                'rgb(84, 109, 254)',
                'rgb(175 ,109, 237)',
                'rgb(244, 167, 66)',
                'rgb(12, 163, 231)',
                'rgb(221 ,58, 82)',
                'rgb(40 ,215 ,133)',
                'rgb(10, 10, 10)'
            ],
            borderWidth: 1
        }]
    };
    const config1 = {
        type: 'bar',
        data: data1,
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        },
    };
    const myChart1 = new Chart(
        document.getElementById('chartjs-bar'),
        config1
    );

    /* pie chart */
    const data2 = {
        labels: [
            'ابی',
            'بنفش',
            'زرد'
        ],
        datasets: [{
            label: 'تست',
            data: [300, 50, 100],
            backgroundColor: [
                'rgb(84, 109, 254)',
                'rgb(175 ,109, 237)',
                'rgb(244, 167, 66)'
            ],
            hoverOffset: 4
        }]
    };
    const config3 = {
        type: 'pie',
        data: data2,
    };
    const myChart2 = new Chart(
        document.getElementById('chartjs-pie'),
        config3
    );

    /* doughnut chart */
    const data3 = {
        labels: [
            'ابی',
            'بنفش',
            'زرد'
        ],
        datasets: [{
            label: 'تست',
            data: [300, 50, 100],
            backgroundColor: [
                'rgb(84, 109, 254)',
                'rgb(175 ,109, 237)',
                'rgb(244, 167, 66)'
            ],
            hoverOffset: 4
        }]
    };
    const config4 = {
        type: 'doughnut',
        data: data3,
    };
    const myChart3 = new Chart(
        document.getElementById('chartjs-doughnut'),
        config4
    );

    /* mixed chart */
    const data4 = {
        labels:  ['فروردین', 'اردیبهشت', 'خرداد', 'تیر'],
        datasets: [{
            type: 'bar',
            label: 'تست',
            data: [10, 20, 30, 40],
            borderColor: 'rgb(84, 109, 254)',
            backgroundColor: 'rgba(84, 109, 254, 0.2)'
        }, {
            type: 'line',
            label: 'تست',
            data: [50, 50, 50, 50],
            fill: false,
            borderColor: 'rgb(175 ,109, 237)'
        }]
    };
    const config5 = {
        type: 'scatter',
        data: data4,
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    };
    const myChart4 = new Chart(
        document.getElementById('chartjs-mixed'),
        config5
    );

    /* polar area chart */
    const data5 = {
        labels: [
            'ابی',
            'سبز',
            'زرد',
            'خاکستری',
            'بنفش'
        ],
        datasets: [{
            label: 'تست',
            data: [11, 16, 7, 3, 14],
            backgroundColor: [
                'rgb(84, 109, 254)',
                'rgb(75, 192, 192)',
                'rgb(244, 167, 66)',
                'rgb(201, 203, 207)',
                'rgb(175 ,109, 237)'
            ]
        }]
    };
    const config6 = {
        type: 'polarArea',
        data: data5,
        options: {}
    };
    const myChart5 = new Chart(
        document.getElementById('chartjs-polar'),
        config6
    );

    /* radial chart */
    const data6 = {
        labels: [
 'خوردن',
 'نوشیدن',
 'خوابیدن',
 'طراحی',
 'کدگذاری',
 'دوچرخه سواری',
 'دویدن'
 ],
        datasets: [{
            label: 'تست',
            data: [65, 59, 90, 81, 56, 55, 40],
            fill: true,
            backgroundColor: 'rgba(84, 109, 254, 0.2)',
            borderColor: 'rgb(84, 109, 254)',
            pointBackgroundColor: 'rgb(84, 109, 254)',
            pointBorderColor: '#fff',
            pointHoverBackgroundColor: '#fff',
            pointHoverBorderColor: 'rgb(84, 109, 254)'
        }, {
            label: 'تست 2',
            data: [28, 48, 40, 19, 96, 27, 100],
            fill: true,
            backgroundColor: 'rgba(175 ,109, 237, 0.2)',
            borderColor: 'rgb(175 ,109, 237)',
            pointBackgroundColor: 'rgb(175 ,109, 237)',
            pointBorderColor: '#fff',
            pointHoverBackgroundColor: '#fff',
            pointHoverBorderColor: 'rgb(175 ,109, 237)'
        }]
    };
    const config7 = {
        type: 'radar',
        data: data6,
        options: {
            elements: {
                line: {
                    borderWidth: 3
                }
            }
        },
    };
    const myChart6 = new Chart(
        document.getElementById('chartjs-radar'),
        config7
    );

    /* scatter chart */
    const data7 = {
        datasets: [{
            label: 'مجموعه داده پراکنده',
            data: [{
                x: -10,
                y: 0
            }, {
                x: 0,
                y: 10
            }, {
                x: 10,
                y: 5
            }, {
                x: 0.5,
                y: 5.5
            }],
            backgroundColor: 'rgb(84, 109, 254)'
        }],
    };
    const config8 = {
        type: 'scatter',
        data: data7,
        options: {
            scales: {
                x: {
                    type: 'linear',
                    position: 'bottom'
                }
            }
        }
    };
    const myChart7 = new Chart(
        document.getElementById('chartjs-scatter'),
        config8
    );

    /* bubble chart */
    const data8 = {
        datasets: [{
            label: 'تست',
            data: [{
                x: 20,
                y: 30,
                r: 15
            }, {
                x: 40,
                y: 10,
                r: 10
            }],
            backgroundColor: 'rgb(84, 109, 254)'
        }]
    };
    const config9 = {
        type: 'bubble',
        data: data8,
        options: {}
    };
    const myChart8 = new Chart(
        document.getElementById('chartjs-bubble'),
        config9
    );

})();